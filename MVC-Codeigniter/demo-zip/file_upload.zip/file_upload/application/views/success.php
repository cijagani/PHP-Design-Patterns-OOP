<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h3>Your file was successfully uploaded!</h3>  
		
      <?php 
      echo "<pre>";
      print_r($uploaded_data);
      echo "</pre>";
       ?>
</body>
</html>