<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
	echo form_open_multipart('upload/file_upload');
?>
	<center>
		<input type='file' name='fu_profile' size='20' />
		<br/><br/>
		<input type='submit' name='submit' value='upload' name='btn_upload' />
	</center>
<?php
	echo form_close();
	if (isset($error)) {
		print_r($error);
	}
?>
</body>
</html>