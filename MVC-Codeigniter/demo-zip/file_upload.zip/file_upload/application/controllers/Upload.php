<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

	public function index()
	{
		
	}

	public function file_upload()
	{
		$config['upload_path']="./uploads/";
		$config['allowed_types']="jpg|png|gif";
		$config['max_size']="100";

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('fu_profile')) {
			$data=array("uploaded_data"=>$this->upload->data());
			$this->load->view('success', $data);
		}
		else{
			$error=array("error"=>$this->upload->display_errors());
			$this->load->view('view_profile', $error);
		}
	}




}

/* End of file Upload.php */
/* Location: ./application/controllers/Upload.php */