<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'libraries/kint.phar');
class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form'));
		//Do your magic here
	}

	public function index()
	{
		
	}

	public function sign_in()
	{
		$data['title']="Student Registration System";
		$this->load->view('student_signin', $data, FALSE);	
	}

	public function do_signin()
	{
		
		$posted_data=$this->input->post();
		if (isset($posted_data['btn_submit'])) {
			d($this->input->post());
			/*echo "<pre>";
				print_r($this->input->post());
			echo "</pre>";*/
		}
		else{
			redirect(site_url('auth/sign_in'),'refresh');
		}
	}

}

/* End of file Auth.php */
/* Location: ./application/controllers/Auth.php */