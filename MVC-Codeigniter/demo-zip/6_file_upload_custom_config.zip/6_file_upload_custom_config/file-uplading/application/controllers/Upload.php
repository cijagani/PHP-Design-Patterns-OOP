<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		
	}

	public function do_upload()
	{
		//load custom config file.
		$upload_config=$this->config->load('upload');


        // load config array to upload libary
		$this->load->library('upload', $upload_config);

		//do upload file
		if ($this->upload->do_upload('fu_upload')) {

			// store uploaded file information to $data array
			$data=array("uploaded_data"=>$this->upload->data());

			//load view and pass data
			$this->load->view('success', $data);
		}

		// if error during file upload
		else{
			// store all uploading related errors in array
			$errors=array("error"=>$this->upload->display_errors());

			//return to file upload view and pass error message array
			$this->load->view('welcome_message', $errors);
		}
		
	}
}

/* End of file Upload.php */
/* Location: ./application/controllers/Upload.php */