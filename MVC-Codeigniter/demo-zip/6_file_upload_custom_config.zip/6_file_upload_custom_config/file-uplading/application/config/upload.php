<?php
	// set upload path
	$config['upload_path']			="./uploads/";

	//allowed file extentions
	$config['allowed_types']		="jpg|png|gif";

	//logic for auto file name
	//$config['file_name']=time();

	//set encrypt_name to true so file name will be random string
	$config['encrypt_name']			=TRUE;

	//max file size in kb
	$config['max_size']             = 500;

	//max file width in pixel
	$config['max_width']            = 1024;

	//max file height in pixel
	$config['max_height']           = 768;

?>