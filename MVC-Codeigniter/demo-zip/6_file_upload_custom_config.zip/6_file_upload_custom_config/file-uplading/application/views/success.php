<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>files are uploaded successfully!</h3>
	<?php  foreach ($uploaded_data as $item=>$value): ?>
		<li>
			<?php echo $item ?> : <?php echo $value ?>
		</li>
	<?php endforeach; ?>

	<a href="<?php echo site_url('welcome/index'); ?>"> Back to Previous page.</a>
</body>
</html>