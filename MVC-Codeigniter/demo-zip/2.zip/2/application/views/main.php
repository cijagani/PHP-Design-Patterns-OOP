<div class="row">
	<div class="col-md-2">
	</div>
	<div class="col-md-8">
		<div class="panel panel-danger">
			<div class="panel-heading">
				demo of URL helper
			</div>
			<div class="panel-body">
				<code>base_url() : <?php echo base_url();?></code>
				<br/><br/>
				<code>index page : <?php echo index_page();?></code>
				<br/><br/>
				<code>current url : <?php echo current_url();?></code>
				<br/><br/>
				<code>uri_string : <?php echo uri_string();?></code>
			</div>
		</div>
	</div>
	<div class="col-md-2">
	</div>
</div>