

</div>
<script type="text/javascript" src=<?php echo base_url('/assets/js/bootstrap.min.js'); ?>></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		
	});
</script>
</body>
</html>  