<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootstrap.min.css") ;?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootstrap-theme.min.css") ;?>">
	<script type="text/javascript" src="<?php echo base_url("/assets/js/jquery-3.3.1.min.js"); ?>"></script>
	
</head>
<body>
<div class="container">

	<div class="row">
			<div class="col-md-6">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Codeigniter is PHP based MVC Framework</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-danger">
					<div class="panel-heading">Panel with panel-danger class</div>
					<div class="panel-body">LARAVEL is PHP based MVC Framework</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
	</div>

	<div class="row">
			<div class="col-md-6">
				<div class="panel panel-info">
					<div class="panel-heading">Panel with panel-info class</div>
					<div class="panel-body">AngularJS is JAVASCRIPT based MVC Framework</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-warning">
					<div class="panel-heading">Panel with panel-warning class</div>
					<div class="panel-body">WORDPRESS is PHP based CMS Framework</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
	</div>

	<div class="row">
			<div class="col-md-6">
				<div class="panel panel-success">
					<div class="panel-heading">Panel with panel-success class</div>
					<div class="panel-body">Panel Content</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-default">
					<div class="panel-heading">Panel with panel-default class</div>
					<div class="panel-body">Panel Content</div>
					<div class="panel-footer">Panel Footer</div>
  				</div>
			</div>
	</div>

</div>
	<script type="text/javascript" src="<?php echo base_url("/assets/js/bootstrap.js"); ?>"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			//alert("hi");
		});
	</script>
</body>
</html>