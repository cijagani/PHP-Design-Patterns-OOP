<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//add kint php debuger
require_once(APPPATH."/third_party/kint.phar");
class Directory_helper extends CI_Controller {

	public function index()
	{
		//load directory helper
		$this->load->helper('directory');

		//directory_map($source_dir[, $directory_depth = 0[, $hidden = FALSE]])
		$map=directory_map(APPPATH,FALSE,false);
		$data['map']=$map;
		d($map);
		$this->load->view('view_direcotry_helper',$data);
	}

}

/* End of file Directory_helper.php */
/* Location: ./application/controllers/Directory_helper.php */