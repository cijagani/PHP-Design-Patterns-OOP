<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
	foreach ($map as $folders_name=>$folders) {
		echo "<b>{$folders_name}</b><br/>";
	}
?>
</body>
</html>