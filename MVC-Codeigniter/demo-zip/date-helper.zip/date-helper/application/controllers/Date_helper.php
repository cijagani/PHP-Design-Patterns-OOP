<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once(APPPATH."/third_party/kint.phar");

class Date_helper extends CI_Controller {

	public function index()
	{
		$this->load->helper('date');
		$this->load->view('view_date_helper');	
	}

}

/* End of file Date_helper.php */
/* Location: ./application/controllers/Date_helper.php */