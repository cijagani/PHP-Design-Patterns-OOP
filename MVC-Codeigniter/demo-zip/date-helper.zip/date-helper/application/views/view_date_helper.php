<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	now() :<?php  echo now('Asia/Calcutta'); ?>
	<br/><br/>

	mdate(): 
	<?php 
		$datestring = 'Year: %Y Month: %m Day: %d - %h:%i %a';
		$time = time();
		echo mdate($datestring, $time); 
	?>
	<br/><br/>
	days_in_month : <?php echo days_in_month(02,2001); ?>
	<br/><br/>
	Date range :
	<select>
	<?php 
		$range = date_range('2019-01-01', '2019-01-15');
		echo "First 15 days of 2019:<br/>";
		foreach ($range as $date)
		{
			echo "<option>";
		    echo $date."<br/>";
		    echo "</option>";
		}
	 ?>
	 </select>
	 <br/><br/>
	 timezone_menu :
	 <?php 
	 	echo timezone_menu('UP55');
	  ?>
</body>
</html>