<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootstrap.min.css"); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/bootstrap-theme.min.css"); ?>">
</head>
<body>
	<div class="col-md-3">
	</div>
	<div class="col-md-6">
		<br/><br/>
		<form class="form-horizontal jumbotron" action="<?php echo site_url('auth/do_sign_in') ?>" method="post">
			<fieldset>

			<!-- Form Name -->
			<legend>Form Name</legend>
			<?php //echo validation_errors(); ?>

			<!-- Text input-->
			<div class="form-group <?php  if(form_error('txt_username')) echo "has-error"?>">
			  <label class="col-sm-4 control-label" for="txt_username">Username *</label>
			  <div class="col-sm-6">
			    <input id="txt_username" name="txt_username" type="text" placeholder="Enter your username" class="form-control input-md">
			    <?php echo form_error('txt_username'); ?>
			  </div>
			</div>

			<!-- Password input-->
			<div class="form-group <?php  if(form_error('txt_password')) echo "has-error"?>">
			  <label class="col-sm-4 control-label" for="txt_password">Password *</label>
			  <div class="col-sm-6">
			    <input id="txt_password" name="txt_password" type="password" placeholder="Enter your Password" class="form-control input-md">
			     <?php echo form_error('txt_password'); ?>
			  </div>
			</div>

			<!-- Button -->
			<div class="form-group">
			  <label class="col-md-4 control-label" for="btn_submit"></label>
			  <div class="col-md-4">
			    <button id="btn_submit" name="btn_submit" class="btn btn-primary">Login</button>
			  </div>
			</div>

			</fieldset>
			</form>
	</div>
	<div class="col-md-3">
	</div>
</body>
</html>