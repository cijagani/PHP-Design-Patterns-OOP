<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('form_validation');
	}
	public function index()
	{
		
	}
	public function sign_in(){
		$this->load->view('view_student_signin');
	}
	public function do_sign_in(){
		$posted_data=$this->input->post();
		if(isset($posted_data['btn_submit'])){
			$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
			$this->form_validation->set_rules('txt_username', 'username', 'required|min_length[5]|max_length[10]|trim|alpha');
			$this->form_validation->set_rules('txt_password', 'password', 'required|min_length[5]|max_length[10]|trim');

			if ($this->form_validation->run() == FALSE) {
				$this->sign_in();
			}
			else{
				print_r($posted_data);
				//echo "ok ok fine fine";
			}
		}
		else{
			redirect(site_url('auth/sign_in'),'refresh');
		}
		//$this->form_validation->set_rules("controller name","message","rule name");
		
	}

}

/* End of file Auth.php */
/* Location: ./application/controllers/Auth.php */