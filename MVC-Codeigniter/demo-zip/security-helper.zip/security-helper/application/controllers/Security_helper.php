<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'third_party/kint.phar');
class Security_helper extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','security','form'));
	}

	public function index()
	{
		$data['title']="Student Registration System";
		$this->load->view('student_signin', $data, FALSE);	
	}

	public function do_signin()
	{
		
		$posted_data=$this->input->post();
		if (isset($posted_data['btn_submit'])) {

			// non-xss data
			d($posted_data);

			//// Apply the xss_clean() of "security" library, which filtered data from passing through <script> tag.
			$xss_data = xss_clean($posted_data);

			d($xss_data);

			$encrypted_md5=do_hash($xss_data['txt_password'], 'md5');
			d($encrypted_md5);

			$encrypted=do_hash($xss_data['txt_password']);
			d($encrypted);
			

			d(hash_algos());
			
			
		}
		else{
			redirect(site_url('security_helper/sign_in'),'refresh');
		}
	}

}

/* End of file Security_helper.php */
/* Location: ./application/controllers/Security_helper.php */