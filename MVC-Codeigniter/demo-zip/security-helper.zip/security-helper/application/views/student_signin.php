<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/bootstrap.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/bootstrap-theme.min.css'); ?>">
	<script type="text/javascript" src=<?php echo base_url('/assets/js/jquery-3.3.1.min.js'); ?>></script>


</head>
<body>
	<br/>
	<div class="container">
		<div class="row">
			<?php 
			$attributes=array("class"=>"form-horizontal","id" => "myform");
			echo form_open(site_url('security_helper/do_signin'), $attributes); ?>
			<fieldset>

				<!-- Form Name -->
				<legend><?php echo $title ?></legend>

				<!-- Text input-->
				<div class="form-group">
					<?php  
					$attributes=array("class"=>"col-sm-4 control-label","for"=>"txt_fullname");
					echo form_label('Full Name', 'username', $attributes);
					?>
					<div class="col-sm-6">
						<?php 
						$attributes=array("class"=>"form-control input-md","placeholder"=>"Enter your full name","placeholder"=>"Enter your full name");
						echo form_input('txt_fullname', '', $attributes); 
						?>
					</div>
				</div>

				<!-- Password input-->
				<div class="form-group">
					<label class="col-sm-4 control-label" for="txt_password">Password</label>
					<div class="col-sm-6">
						<input id="txt_password" name="txt_password" type="password" placeholder="Enter your password" class="form-control input-md">

					</div>
				</div>

				<!-- Multiple Radios -->
				<div class="form-group">
					<label class="col-md-4 control-label" for="r_gender">Gender</label>
					<div class="col-md-4">
						<div class="radio">
							<label for="r_gender-0">
								<input type="radio" name="r_gender" id="r_gender-0" value="male" checked="checked">
								Male
							</label>
						</div>
						<div class="radio">
							<label for="r_gender-1">
								<input type="radio" name="r_gender" id="r_gender-1" value="Female">
								Female
							</label>
						</div>

					</div>
				</div>

				<!-- Select Basic -->
				<div class="form-group">
					<label class="col-md-4 control-label" for="drp_branch">Branch</label>
					<div class="col-md-5">
						<select id="drp_branch" name="drp_branch" class="form-control">
							<option value="BCA">BCA</option>
							<option value="BSCIT">BSCIT</option>
							<option value="BVOC">BVOC</option>
							<option value="MSCIT">MSCIT</option>
							<option value="MCA">MCA</option>

						</select>
					</div>
				</div>
				<!-- Multiple Checkboxes -->
				<div class="form-group">
					<label class="col-md-4 control-label" for="languages">Favorite Languages</label>
					<div class="col-md-4">
						<div class="checkbox">
							<label for="languages-0">
								<input type="checkbox" name="languages[]" id="languages-0" value="PHP">
								PHP
							</label>
						</div>
						<div class="checkbox">
							<label for="languages-1">
								<input type="checkbox" name="languages[]" id="languages-1" value="ASP.NET">
								ASP.NET
							</label>
						</div>
						<div class="checkbox">
							<label for="languages-2">
								<input type="checkbox" name="languages[]" id="languages-2" value="JAVA">
								JAVA
							</label>
						</div>
						<div class="checkbox">
							<label for="languages-3">
								<input type="checkbox" name="languages[]" id="languages-3" value="R">
								R
							</label>
						</div>
						<div class="checkbox">
							<label for="languages-4">
								<input type="checkbox" name="languages[]" id="languages-4" value="RUBY">
								RUBY
							</label>
						</div>

					</div>
				</div>

				<!-- Button -->
				<div class="form-group">
					<label class="col-md-4 control-label" for="btn_submit"></label>
					<div class="col-md-4">
						<button id="btn_submit" name="btn_submit" value="submit" class="btn btn-primary">Register</button>
					</div>
				</div>

			</fieldset>
		</form>
	</div>
</div>

