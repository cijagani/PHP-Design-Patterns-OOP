<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Session_demo extends CI_Controller {

	public function index()
	{
		echo "<pre>";
		print_r($this->session->userdata());	
		echo "</pre>";
		echo "<b>Student id:</b> ".$this->session->userdata('student_id');
		echo "<br/>";
		echo "<b>Student Name :</b> ".$this->session->userdata('student_name');
		echo "<br/>";
		echo "<b>Student email:</b> ".$this->session->userdata('student_email');
		echo "<br/>";
		echo "<b>User Role:</b> ".$this->session->userdata('role');
		echo "<br/>";

		print_r($this->session->all_userdata()); // Read all session values
		echo "<br/>";
		//unset role
		$this->session->unset_userdata('role');
		if (!$this->session->userdata('role')) {
			echo "session role is removed";	
			echo "<br/>";
		}
		print_r($this->session->all_userdata());

		$this->session->flashdata('flash_item');
	}

}

/* End of file Session_demo.php */
/* Location: ./application/controllers/Session_demo.php */