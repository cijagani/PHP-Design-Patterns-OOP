<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		/**** SET SESSION DATA ****/
        // set single item in session
        $this->session->set_userdata('session_key', 'session_value');

        // set array of items in session
        $arraydata = array(
                'student_id'  => '01',
                'student_name'     => 'chirag jagani',
                'student_email' => 'trueline.chirag@gmail.com',
                'role' => 'student'
        );
        $this->session->set_userdata($arraydata);

        $this->session->set_flashdata('flash_item',$arraydata);
	}

	public function demo_session(){

		
	}
}

/*
To retrieve session data:

$this->session->userdata('item'); // Where item is the array index like session id
To add custom session data:

$this->session->set_userdata($array); // $array is an associative array of your new data
To retrieve all session data:

$this->session->all_userdata() // Read all session values
To remove all session data:

$this->session->unset_userdata('some_name'); // Removing values from session
*/
